# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## goals

* convert the project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

## content of the page

* header
* footer
* 4 sections
## functionality of the page

 * highlighting navigation bar link while scrolling it section
 * navigate to and highlight section when clicking on it link from nav-bar